<?php

use Faker\Generator as Faker;

$factory->define(App\Product::class, function (Faker $faker) {
    return [
        'title' => $faker->words(),
        'description' => $faker->paragraph(),
        'price' => $faker->randomFloat($nbMaxDecimals = 2, $min = 1, $max = 9999),
        'url_image' => $faker->imageUrl($width = 100, $height = 100, 'fashion'),
        'reference' => $faker->ean8()
    ];
});